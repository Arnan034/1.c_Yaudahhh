/*=================================================================================================
Program : Calculator Scientific
Author : Kelompok 1.c
Kelas : 1B
=================================================================================================*/

#include "calculator.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main(int argc, char *argv[]) {
	runCalc();
    return 0;
}