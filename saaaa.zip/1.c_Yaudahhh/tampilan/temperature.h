#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void mainMenu();
void countCelcius();
void countReamur();
void countKelvin();
void countFahrenheit();
