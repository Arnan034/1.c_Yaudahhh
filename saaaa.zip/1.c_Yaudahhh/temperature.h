#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void TampilanKonversiSuhu();
void mainMenuTemp();
void countCelcius();
void countReamur();
void countKelvin();
void countFahrenheit();
